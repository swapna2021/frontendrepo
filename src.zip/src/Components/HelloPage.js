import React from "react";
function HelloPage(props) {
    

    return (
        <>
            <h4>HELLO</h4>
        </>
    )
}
export default HelloPage
