import React from "react";

const Header=()=>{
    return(
        <div>
            <h1>Bank Account Application</h1>
        </div>
    )
}
export default Header