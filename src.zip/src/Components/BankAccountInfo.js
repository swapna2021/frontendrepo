import React  from "react";
const BankAccountInfo=()=>{
    return (
        <div>
            Bank Account Info
        </div>
    )
}
export default BankAccountInfo