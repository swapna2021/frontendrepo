import React from "react";

const Signup=()=>{
    return (
        <div>
            Signup rendered
        </div>
    )
}
export default Signup